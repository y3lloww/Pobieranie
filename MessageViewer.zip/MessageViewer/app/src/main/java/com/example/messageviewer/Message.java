package com.example.messageviewer;
public class Message {
    private String title;
    private String description;
    private String date;
    private String author;
    private String content;

    // Getters
    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }

    public String getAuthor() {
        return author;
    }

    public String getContent() {
        return content;
    }
}
